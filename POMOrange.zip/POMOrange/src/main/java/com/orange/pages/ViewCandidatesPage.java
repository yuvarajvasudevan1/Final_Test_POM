package com.orange.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.orange.base.BaseTest;
import com.orangehrm.base.Base;

public class ViewCandidatesPage extends BaseTest{
	
	@FindBy(id = "btnAdd") WebElement addBtn;
	
	public ViewCandidatesPage() {
		PageFactory.initElements(driver, this);
		
	}
	
	public void assertViewCandidatesPageTitle() {
		assertEquals(driver.getTitle(), "OrangeHRM");
	}
	
	public AddCandidatePage clickOnAddCandidate() {

		addBtn.click();
		return new AddCandidatePage();
	}
	

}
