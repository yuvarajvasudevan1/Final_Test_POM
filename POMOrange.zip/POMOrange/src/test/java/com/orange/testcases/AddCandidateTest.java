package com.orange.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.orange.base.BaseTest;
import com.orangehrm.base.Base;
import com.orangehrm.pages.AddCandidatePage;
import com.orangehrm.pages.DashboardPage;
import com.orangehrm.pages.LoginPage;
import com.orangehrm.pages.ViewCandidatesPage;

public class AddCandidateTest extends BaseTest{

	LoginPage loginPage;
	DashboardPage dashboardpage;
	ViewCandidatesPage viewCandidatesPage;
	
	
	public AddCandidateTest() {
		super();
	}
	
	@BeforeMethod(alwaysRun = true)
	public void beforeMethod() {
		initialization();
		loginPage = new LoginPage();
		dashboardpage = new DashboardPage();
		viewCandidatesPage = new ViewCandidatesPage();
		
	}
	
	@AfterMethod(alwaysRun = true)
	public void afterMethod() {
		driver.close();
		driver.quit();
	}
	
	@Test
	public void addCandidateTest() {
		loginPage.login();
		viewCandidatesPage = dashboardpage.clickOnCandidateSubMenu();
		AddCandidatePage addCandidatePage = viewCandidatesPage.clickOnAddCandidate();
		addCandidatePage.addCandidate();
	}
}
